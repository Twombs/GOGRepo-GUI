
The 'gogrepo.exe' file, is a compiled version of 'gogrepo.py', and was compiled by Timboli (from the GOG Forums), using the last original version of 'gogrepo.py' as source.

It was compiled on a Windows 7, 32 Bit PC, where Python 3.4 and required libraries were installed, for use with 'gogrepo.py' and 'GOGRepo Simple GUI' and related.

The last original version of 'gogrepo.py', a Python program (script) can be found at GitHub.

https://github.com/eddie3/gogrepo/blob/master/gogrepo.py

That file was uploaded to GitHub two years ago, as of the 13th October 2021.

License: GPLv3+

More information can be found at - https://github.com/eddie3/gogrepo

8 contributors are listed at - https://github.com/eddie3/gogrepo/graphs/contributors

(eddie3, disi, resonantworks, Shiryou, tiehichi, Trilarion, jpenney, HamsterExAstris)

IMPORTANT - Only this compiled version will work properly with 'GOGRepo Simple GUI'.
